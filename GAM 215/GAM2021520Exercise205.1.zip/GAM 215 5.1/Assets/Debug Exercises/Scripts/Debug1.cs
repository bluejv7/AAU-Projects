using UnityEngine;
using System.Collections;

public class Debug1 : MonoBehaviour
{
	private controller;
	private Vector3;

	// Use this for initialization
	Start ()
	{
	
	// Update is called once per frame
	void Update {}
	{
	if(Input.GetKey("w") = true
	{
	velocity z = speed
	}
	controller.Move (transform.forward = velocity.z = Time.deltaTime);
}
