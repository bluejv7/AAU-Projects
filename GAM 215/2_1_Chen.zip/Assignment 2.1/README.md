# Platformer (Part 1) (GAM 215, Module 2, Assignment 2.1: Platformer)

## Main file locations:

* The C# script is located in `Assets/Scripts/CharacterRigidBodyController.cs`
* The Unity scene is located in `Assets/Scenes/PlatformScene.unity`

## Project information

### Unity Scene

1. A player-controlled (player) `GameObject`
2. Multiple platform, obstacle, and enemy game objects
3. A plane for the player and other game objects to land/rest on
4. There are at least 10 game objects
5. I attached the main camera as a child of the player and tweaked the transform values so I could get a proper view of the game environment

### Scripts

I made one script that handles controlling the player through modifying the `Rigidbody` component.
I used the `Physics.checkSphere()` method to detect whether the player is grounded or not based on the example code written by Scott Berkenkotter.
I added 4 directional inputs (W,A,S,D) to move the player (up, down, look left, look right; respectively).
I also added a jump input (spacebar) so the player can hop onto platforms or use it to avoid obstacles/enemies.

Author: Jv Chen

## How does my project satisfy the conditions of the assignment

1. Created a script with 4 directional player inputs
2. Created a platformer level scene with at least 10 objects (currently has 24)
3. Created a player `GameObject` with player controller with necessary components attached (in this case, a `Rigidbody` component)

## Miscellaneous

I did not copy and paste any code, but I did reference the Rigidbody example written by Scott Berkenkotter.
Some of the statements in the code will be the same as the example, but I tried to only apply the concepts
and reuse the same statements if the statement was a basic teaching from the outlines in module 2.

I updated the rigidbody controller with the new example that Scott Berkenkotter provided and modified a few things.

1. I moved part of the offset calculations for the `colliderBottom` to the `awake()` function, since I do not expect to modify
the capsule collider's height/radius/offset or the capsule character's height/radius/offset.
2. I modified the `Physics.checkSphere()` radius parameter, since I still had an issue with my character being unable to jump some of the time.
I deviated from the example by using the collider's actual radius instead of `radius - 0.1f`, knowing that it is detecting 0.1 meters farther
than it should, but will not have the jumping issue.  The player will be able to jump a little sooner than they are supposed to,
but it is not noticeable (to me, at least).